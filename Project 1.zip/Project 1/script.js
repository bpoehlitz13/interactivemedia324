        $('.drawing').click(function(){
          $(this).attr("background-color", funtion() {
          	return "darkblue";
          })
        };